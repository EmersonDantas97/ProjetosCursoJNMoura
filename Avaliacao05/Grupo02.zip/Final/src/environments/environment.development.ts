export const environment = {

    urlBase: "https://localhost:44391/api"

};
