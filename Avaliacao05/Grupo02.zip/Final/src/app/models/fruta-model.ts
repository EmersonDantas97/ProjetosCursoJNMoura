export interface FrutaModel {
    Id: number,
    Nome: string,
    DataVenc: Date
}