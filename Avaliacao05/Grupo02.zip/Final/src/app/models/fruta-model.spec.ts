import { FrutaModel } from './fruta-model';

describe('FrutaModel', () => {
  it('should create an instance', () => {
    expect(new FrutaModel()).toBeTruthy();
  });
});
