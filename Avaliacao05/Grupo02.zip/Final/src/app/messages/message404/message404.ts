import { Component } from '@angular/core';

@Component({
  selector: 'app-message404',
  imports: [],
  templateUrl: './message404.html',
  styleUrl: './message404.css'
})
export class Message404 {

}
